import os
import tkinter as tk
from tkinter import messagebox, filedialog, ttk

class YapayZekaTestEkrani:
    def __init__(self, root):
        self.root = root
        self.root.title("Yapay Zeka Test Ekranı")
        self.root.geometry("600x400")

        self.veri_seti_secildi = False
        self.model_secildi = False
        self.test_orani_belirlendi = False
        self.veri_seti_adi = ""
        self.veri_seti_turu = ""

        self.baslik_olustur()
        self.radio_butonlari_olustur()
        self.test_et_butonu_olustur()

    def baslik_olustur(self):
        self.baslik = tk.Label(self.root, text="Test İşlemine Başlamak İçin Sırasıyla Aşağıdaki İşlemleri Uygulayınız.",
                               font=("Arial", 12), wraplength=500, justify="center")
        self.baslik.pack(pady=10)

    def radio_butonlari_olustur(self):
        self.radio_frame = tk.Frame(self.root)
        self.radio_frame.pack(pady=20)

        self.btn1 = tk.Button(self.radio_frame, text="1- veri setini dosyaya ekle", command=self.veri_seti_ekle)
        self.btn1.grid(row=0, column=0, padx=10, pady=5)

        self.label1 = tk.Label(self.radio_frame, text="")
        self.label1.grid(row=0, column=1, padx=10)

        self.btn2 = tk.Button(self.radio_frame, text="2- kullanılacak modeli seç", command=self.model_sec, state="disabled")
        self.btn2.grid(row=1, column=0, padx=10, pady=5)

        self.btn3 = tk.Button(self.radio_frame, text="3- veri seti test oranını belirle", command=self.test_orani_sec, state="disabled")
        self.btn3.grid(row=2, column=0, padx=10, pady=5)

    def test_et_butonu_olustur(self):
        self.test_butonu = tk.Button(self.root, text="Veri Setini Test Et", command=self.test_et, state="disabled")
        self.test_butonu.pack(pady=10)

    def veri_seti_ekle(self):
        pencere = tk.Toplevel(self.root)
        pencere.title("Veri Seti Türü Seçimi")
        pencere.geometry("300x200")

        tk.Label(pencere, text="Veri Seti Türünü Seçin:").pack(pady=10)
        tur = tk.StringVar()

        # Verilen seçeneklerin başta işaretli olmaması için her şeyin tıkısız olmasını sağlıyoruz
        tur.set(None)

        tk.Radiobutton(pencere, text="Sayısal Veri Seti", variable=tur, value="Sayısal").pack(anchor="w")
        tk.Radiobutton(pencere, text="Metinsel Veri Seti", variable=tur, value="Metinsel").pack(anchor="w")
        tk.Radiobutton(pencere, text="Görsel Veri Seti", variable=tur, value="Görsel").pack(anchor="w")

        def onayla():
            secim = tur.get()
            if not secim:
                messagebox.showwarning("Uyarı", "Lütfen bir veri seti türü seçin.")
                return

            messagebox.showinfo("Bilgi",
                                "PROGRAM SİZİN SEÇTİĞİNİZ TÜRDE VERİ SETİNİ HAFIZAYA ALACAK.\nLÜTFEN TEST SIRASINDA HATA OLMAMASI İÇİN DOĞRU SEÇİM YAPTIĞINIZDAN EMİN OLUN.")
            self.veri_seti_turu = secim

            klasor = "veri_setleri"
            if not os.path.exists(klasor):
                os.makedirs(klasor)

            dosyalar = [f for f in os.listdir(klasor) if f.endswith(".csv")]
            if not dosyalar:
                messagebox.showwarning("Uyarı", "Klasörde hiç .csv dosyası bulunamadı.")
                pencere.destroy()
                return

            combo = ttk.Combobox(pencere, values=dosyalar)
            combo.pack(pady=10)

            def dosya_onayla():
                secilen = combo.get()
                if not secilen:
                    messagebox.showwarning("Uyarı", "Lütfen bir dosya seçin.")
                    return
                self.veri_seti_adi = secilen
                self.label1.config(text=f"{secilen} ({self.veri_seti_turu})")
                self.btn1.config(state="disabled")
                self.btn2.config(state="normal")
                pencere.destroy()  # Pencereyi kapatıyoruz

            tk.Button(pencere, text="Onayla", command=dosya_onayla).pack(pady=5)

        tk.Button(pencere, text="Seçimi Onayla", command=onayla).pack(pady=5)

    def model_sec(self):
        self.model_secildi = True
        self.btn2.config(state="disabled")
        self.btn3.config(state="normal")

    def test_orani_sec(self):
        self.test_orani_belirlendi = True
        self.btn3.config(state="disabled")
        self.test_butonu.config(state="normal")

    def test_et(self):
        messagebox.showinfo("Test", f"Veri seti: {self.veri_seti_adi}\nTür: {self.veri_seti_turu}\nModel test ediliyor...")

if __name__ == '__main__':
    root = tk.Tk()
    app = YapayZekaTestEkrani(root)
    root.mainloop()
